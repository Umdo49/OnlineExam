package com.oExam.onlineExam.controller;

import com.oExam.onlineExam.model.User;
import com.oExam.onlineExam.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;


@RestController
@RequestMapping("/api/users")
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody User user) {
        if (userService.getByEmail(user.getEmail()).isPresent()) {
            return ResponseEntity.badRequest().body("E-posta zaten kayıtlı.");
        }
        return ResponseEntity.ok(userService.saveUser(user));
    }

    @GetMapping("/login")
    public ResponseEntity<?> login(@RequestParam String email) {
        Optional<User> userOpt = userService.getByEmail(email);
        if (userOpt.isEmpty()) {
            return ResponseEntity.status(404).body("Kullanıcı bulunamadı.");
        }
        userService.updateLastLogin(email);
        return ResponseEntity.ok(userOpt.get());
    }

    @PostMapping("/verify-email")
    public ResponseEntity<?> verifyEmail(@RequestParam String email) {
        return userService.verifyEmail(email) ?
                ResponseEntity.ok("E-posta doğrulandı.") :
                ResponseEntity.status(404).body("Kullanıcı bulunamadı.");
    }

    @PostMapping("/verify-phone")
    public ResponseEntity<?> verifyPhone(@RequestParam String phone) {
        return userService.verifyPhone(phone) ?
                ResponseEntity.ok("Telefon doğrulandı.") :
                ResponseEntity.status(404).body("Kullanıcı bulunamadı.");
    }
}


