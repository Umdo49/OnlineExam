package com.oExam.onlineExam.controller;

import com.oExam.onlineExam.model.Exam;
import com.oExam.onlineExam.service.ExamService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/exams")
@RequiredArgsConstructor
public class ExamController {

    ExamService examService;

    // Sınav oluşturma
    @PostMapping("/create")
    public ResponseEntity<Exam> createExam(@RequestBody Exam exam) {
        return ResponseEntity.ok(examService.createExam(exam));
    }

    // Kullanıcıya ait sınavları listeleme
    @GetMapping("/creator/{creatorId}")
    public ResponseEntity<List<Exam>> getExamsByCreator(@PathVariable Long creatorId) {
        return ResponseEntity.ok(examService.getExamsByCreator(creatorId));
    }

    // Yayınlanmış sınavı görüntüleme
    @GetMapping("/{examId}")
    public ResponseEntity<Exam> getPublishedExam(@PathVariable Long examId) {
        return examService.getPublishedExam(examId)
                .map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(404).body(null));
    }

    // Yayınlanmış tüm sınavları listeleme
    @GetMapping("/published")
    public ResponseEntity<List<Exam>> getPublishedExams() {
        return ResponseEntity.ok(examService.getPublishedExams());
    }

    // Sınavı yayınlama
    @PostMapping("/publish/{examId}")
    public ResponseEntity<Exam> publishExam(@PathVariable Long examId) {
        return ResponseEntity.ok(examService.publishExam(examId));
    }

    // Sınavın süresi dolmuş mu kontrolü
    @GetMapping("/expired/{examId}")
    public ResponseEntity<Boolean> isExamExpired(@PathVariable Long examId) {
        return ResponseEntity.ok(examService.isExamExpired(examId));
    }
}

