package com.oExam.onlineExam.controller;

import com.oExam.onlineExam.dto.PaymentRequest;
import com.oExam.onlineExam.dto.PaymentResponse;
import com.oExam.onlineExam.model.Payment;
import com.oExam.onlineExam.service.PaymentService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/payments")
@RequiredArgsConstructor
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    // Ödeme işlemini başlatma
    @PostMapping("/pay")
    public ResponseEntity<Payment> makePayment(@RequestBody Payment payment) {
        Payment processedPayment = paymentService.processPayment(payment);
        return ResponseEntity.ok(processedPayment);
    }

    // Kullanıcıya ait ödemeleri listeleme
    @GetMapping("/user/{userId}")
    public ResponseEntity<List<Payment>> getPaymentsByUser(@PathVariable Long userId) {
        List<Payment> payments = paymentService.getPaymentsByUserId(userId);
        return ResponseEntity.ok(payments);
    }

    // Sınav id'sine göre ödemeleri listeleme
    @GetMapping("/exam/{examId}")
    public ResponseEntity<List<Payment>> getPaymentsByExam(@PathVariable Long examId) {
        List<Payment> payments = paymentService.getPaymentsByExamId(examId);
        return ResponseEntity.ok(payments);
    }

    // Ödeme durumunu güncelleme
    @PutMapping("/update/{paymentId}")
    public ResponseEntity<Payment> updatePaymentStatus(@PathVariable Long paymentId, @RequestParam String status) {
        Payment updatedPayment = paymentService.updatePaymentStatus(paymentId, status);
        if (updatedPayment != null) {
            return ResponseEntity.ok(updatedPayment);
        }
        return ResponseEntity.notFound().build();
    }
}
