package com.oExam.onlineExam.repository;

import com.oExam.onlineExam.model.Exam;
import com.oExam.onlineExam.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.Optional;


import org.springframework.data.jpa.repository.JpaRepository;
@Repository
public interface ExamRepository extends JpaRepository<Exam, Long> {
    List<Exam> findByCreatorId(Long creatorId); // Kullanıcıya göre sınavları getirme
    Optional<Exam> findByIdAndIsPublishedTrue(Long id); // Yayınlanmış sınavı getirme
    List<Exam> findByIsPublishedTrue(); // Tüm yayınlanmış sınavları listeleme
}


