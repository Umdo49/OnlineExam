package com.oExam.onlineExam.repository;

import com.oExam.onlineExam.model.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long> {

    List<Payment> findByUserId(Long userId); // Kullanıcıya ait ödemeleri bulma
    List<Payment> findByExamId(Long examId); // Sınav id'sine göre ödeme listesi
}

