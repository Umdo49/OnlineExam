package com.oExam.onlineExam.model;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;


import jakarta.persistence.*;
        import lombok.Data;

@Entity
@Data
public class Question {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String questionText; // Soru metni
    private String optionA; // A şıkkı
    private String optionB; // B şıkkı
    private String optionC; // C şıkkı
    private String optionD; // D şıkkı
    private String correctAnswer; // Doğru cevap (A, B, C, D)

    @ManyToOne
    @JoinColumn(name = "exam_id")
    private Exam exam; // Soru hangi sınavla ilişkili

    private String questionType; // Soru türü (Çoktan Seçmeli, Klasik, vb.)
}


