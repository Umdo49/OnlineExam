package com.oExam.onlineExam.model;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;


@Entity
@Data
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String email;
    private String phone;
    private String password;

    // Kullanıcı rolleri: CREATOR (sınav oluşturan), PARTICIPANT (katılımcı), ADMIN
    private String role;

    // E-posta veya SMS doğrulama
    private boolean emailVerified;
    private boolean phoneVerified;

    // Hesap oluşturma zamanı ve son giriş zamanı
    private LocalDateTime createdAt;
    private LocalDateTime lastLogin;

    // Hesap aktif mi?
    private boolean active;

    // Ödeme bilgisi var mı? (Katılımcılar için gerekli)
    private boolean paymentVerified;

    // Kullanıcı profili (opsiyonel)
    private String profileImageUrl;
    private String bio;
}


