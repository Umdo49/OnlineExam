package com.oExam.onlineExam.model;

public enum QuestionType {
    MULTIPLE_CHOICE,
    CLASSIC,
    ESSAY
}
