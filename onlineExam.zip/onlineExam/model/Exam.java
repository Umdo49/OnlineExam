package com.oExam.onlineExam.model;


import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Data
public class Exam {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title; // Sınav başlığı (örneğin, YDS, YÖKDİL, vb.)
    private String description; // Sınav açıklaması
    private LocalDateTime startTime; // Sınavın başlama saati
    private LocalDateTime endTime; // Sınavın bitiş saati
    private boolean isPublished; // Sınav yayında mı?
    private boolean isPaid; // Ücretli sınav mı?

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "creator_id")
    private User creator; // Sınavı oluşturan kullanıcı

    @OneToMany(mappedBy = "exam", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Question> questions; // Sınav soruları

    @OneToMany(mappedBy = "exam", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Participation> participations; // Katılımlar

    private int duration; // Sınav süresi (dakika)
}
