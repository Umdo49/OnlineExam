package com.oExam.onlineExam.model;

import jakarta.persistence.*;
import lombok.Data;

import java.sql.ConnectionBuilder;
import java.time.LocalDateTime;

@Entity
@Data
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Double amount; // Ödeme miktarı
    private String paymentMethod; // Ödeme yöntemi (Kredi kartı, banka transferi vs.)
    private String status; // Ödeme durumu (Ödendi, Bekliyor, İptal Edildi)
    private LocalDateTime paymentDate; // Ödeme tarihi ve saati

    @ManyToOne
    @JoinColumn(name = "user_id")
    private User user; // Hangi kullanıcı ödeme yaptı

    @ManyToOne
    @JoinColumn(name = "exam_id")
    private Exam exam; // Hangi sınav için ödeme yapıldı
}
