package com.oExam.onlineExam.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class UserDTO {
    private Long id;
    private String name;
    private String email;
    private String phone;
    private String role;
    private boolean active;
    private boolean emailVerified;
    private boolean phoneVerified;
    private LocalDateTime lastLogin;
}



