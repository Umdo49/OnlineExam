package com.oExam.onlineExam.dto;

import lombok.*;
import java.time.LocalDateTime;

@Data
public class ExamDTO {
    private Long id;
    private String title;
    private String description;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private boolean isPublished;
    private boolean isPaid;
    private int duration;
}


