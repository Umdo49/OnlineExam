package com.oExam.onlineExam.dto;

import lombok.*;
import java.util.List;

@Data
public class QuestionDTO {

    private Long id;
    private String questionText;
    private String optionA;
    private String optionB;
    private String optionC;
    private String optionD;
    private String correctAnswer;
    private Long examId; // Soru hangi sınavla ilişkili
    private String questionType; // Soru türü
}

