package com.oExam.onlineExam.dto;

import lombok.Data;
import java.math.BigDecimal;

@Data
public class PaymentRequest {
    private Long userId;
    private Long examId;
    private BigDecimal amount;
    private String paymentMethod; // örn: CREDIT_CARD, EFT, etc.
}
