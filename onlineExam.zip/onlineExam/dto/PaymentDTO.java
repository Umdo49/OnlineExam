package com.oExam.onlineExam.dto;

import lombok.Data;

import java.time.LocalDateTime;
import java.util.Date;
@Data
public class PaymentDTO {

    private Long id;
    private Double amount;
    private String paymentMethod;
    private String status;
    private Long userId;
    private Long examId;
}

